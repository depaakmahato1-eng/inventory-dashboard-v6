Inventory Dashboard v6
- Features: removed unwanted departments; status colors; per-department WhatsApp numbers with auto alerts; logo upload; expiry automation and cleanup after 45 days; admin permissions; exports (CSV/XLSX/PDF).
- Default admin: admin / admin1234@
- To use: unzip and open index.html in a modern browser. Data is stored in localStorage.
